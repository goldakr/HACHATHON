# Table with 3 rows and 6 columns. Columns: 178, 761 67, 779 61 and 3 more columns. Contains 7 numeric values.

| 178 | 761 67 | 779 61 | 108 40 | 572 9 | 302 |
|---|---|---|---|---|---|
| )ב( תוימרפ ירזחה יוכינב וטורב תוימרפ |  |  |  |  |  |
| 3-74 |  |  |  |  |  |

**Table ID:** table_ayalon_q1_2025_0109_34
**Page:** 118
**Rows:** 3
**Columns:** 6
**Created:** 2025-08-27T20:30:30.993043
