# Table with 3 rows and 1 columns. Columns: םויב ומייתסהש םישדוח השישל. Contains 2 numeric values.

| םויב ומייתסהש םישדוח השישל |
|---|
| 2025 | ינויב 30 |
| כ"הס )א( רחא שוכר בכר הבוח בכר |

**Table ID:** table_ayalon_q1_2025_0097_4
**Page:** 106
**Rows:** 3
**Columns:** 1
**Created:** 2025-08-27T20:30:30.678954
