# Table with 3 rows and 4 columns. Columns: 11, 120 8, 092 13 and 1 more columns. Contains 18 numeric values.

| 11 | 120 8 | 092 13 | 011 תוריחס ןניאש תוינמ |
|---|---|---|---|
| 1 | 178 | 165 1 | 045 | 043 1 | 371 | 952 תוריחס תוינמ |
| 1 | 189 | 285 1 | 053 | 135 1 | 384 | 963 ןוה ירישכמ לכה ךס |

**Table ID:** table_ayalon_q1_2025_0111_19
**Page:** 120
**Rows:** 3
**Columns:** 4
**Created:** 2025-08-27T20:30:31.019958
