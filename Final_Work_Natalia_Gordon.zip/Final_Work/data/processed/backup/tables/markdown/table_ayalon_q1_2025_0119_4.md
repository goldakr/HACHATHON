# Table with 2 rows and 1 columns. Columns: יללכ חוטיב ןוכסיחו.

| יללכ חוטיב ןוכסיחו |
|---|
| כ"הס כ"הס חוטיב רושיוו הרבחה תואירב חווט ךורא |

**Table ID:** table_ayalon_q1_2025_0119_4
**Page:** 128
**Rows:** 2
**Columns:** 1
**Created:** 2025-08-27T20:30:31.155898
