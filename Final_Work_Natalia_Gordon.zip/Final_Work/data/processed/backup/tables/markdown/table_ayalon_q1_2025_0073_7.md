# Table with 4 rows and 1 columns. Columns: קיתה ייח ךשמ. Contains 2 numeric values.

| קיתה ייח ךשמ |
|---|
| 60 45 35 25 15 10 הנש |
| םינש םינש םינש םינש םינש םינש םינש 5 םינש 3 תחא |
| יולת וניאש ןוכסיח ביכר תוללוכה תוסילופ |

**Table ID:** table_ayalon_q1_2025_0073_7
**Page:** 82
**Rows:** 4
**Columns:** 1
**Created:** 2025-08-27T20:30:30.090716
