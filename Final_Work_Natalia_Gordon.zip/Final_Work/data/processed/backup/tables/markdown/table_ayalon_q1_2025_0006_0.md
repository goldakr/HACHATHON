# Table with 3 rows and 1 columns. Columns: 0.6% 2.1% )9.3%( 3.6% )7.5%(. Contains 2 numeric values.

| 0.6% 2.1% )9.3%( 3.6% )7.5%( |
|---|
| ואיבה )3%( לארשי קנב לש ןוילעה רלוד |
| קנב לש תיראטינומה תוינידמהש ךכל |

**Table ID:** table_ayalon_q1_2025_0006_0
**Page:** 10
**Rows:** 3
**Columns:** 1
**Created:** 2025-08-27T20:30:28.694046
