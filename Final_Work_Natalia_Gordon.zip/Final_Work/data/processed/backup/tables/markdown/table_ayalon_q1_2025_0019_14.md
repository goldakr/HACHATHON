# Table with 4 rows and 4 columns. Columns: 145 3, 794 16, 757 20 and 1 more columns. Contains 13 numeric values.

| 145 3 | 794 16 | 757 20 | 696 4-6/2025 |
|---|---|---|---|
| )95( 5 | 811 21 | 563 27 | 278 4-6/2024 |
| 240 )2 | 017( )4 | 805( )6 | 582( יוניש |
| 1 - 22 |  |  |  |

**Table ID:** table_ayalon_q1_2025_0019_14
**Page:** 25
**Rows:** 4
**Columns:** 4
**Created:** 2025-08-27T20:30:29.083955
