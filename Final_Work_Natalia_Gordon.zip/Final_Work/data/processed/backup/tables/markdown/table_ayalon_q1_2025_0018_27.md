# Table with 3 rows and 5 columns. Columns: 337, 4,905, 22,190 and 2 more columns. Contains 14 numeric values.

| 337 | 4,905 | 22,190 | 27,432 | 1-6/2025 |
|---|---|---|---|---|
| )157( | 8,339 | 31,082 | 39,264 | 1-6/2024 |
| 494 | )3,434( | )8,892( | )11,832( | יוניש |

**Table ID:** table_ayalon_q1_2025_0018_27
**Page:** 24
**Rows:** 3
**Columns:** 5
**Created:** 2025-08-27T20:30:29.017819
