# Table with 5 rows and 1 columns. Columns: ךייר ןורש ןלפק רודגיבא. Contains 2 numeric values.

| ךייר ןורש ןלפק רודגיבא |
|---|
| יללכ להנמ ןוירוטקרידה ר"וי |
| 2025 טסוגואב 24 |
| ה"פשת | באב 'ל |
| 1 - 34 |

**Table ID:** table_ayalon_q1_2025_0030_5
**Page:** 37
**Rows:** 5
**Columns:** 1
**Created:** 2025-08-27T20:30:29.278375
