# Table with 3 rows and 1 columns. Columns: 31 םויב םישדוח השולשל םישדוח השישל. Contains 3 numeric values.

| 31 םויב םישדוח השולשל םישדוח השישל |
|---|
| רבמצדב ינויב 30 םויב ומייתסהש ינויב 30 םויב ומייתסהש |
| 2024 2024 2025 2024 2025 |

**Table ID:** table_ayalon_q1_2025_0039_3
**Page:** 48
**Rows:** 3
**Columns:** 1
**Created:** 2025-08-27T20:30:29.409320
