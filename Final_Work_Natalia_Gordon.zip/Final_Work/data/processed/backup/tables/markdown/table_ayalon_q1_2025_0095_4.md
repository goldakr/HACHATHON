# Table with 3 rows and 1 columns. Columns: םויב ומייתסהש םישדוח השולשל. Contains 2 numeric values.

| םויב ומייתסהש םישדוח השולשל |
|---|
| 2024 | ינויב 30 |
| כ"הס )א( רחא שוכר בכר הבוח בכר |

**Table ID:** table_ayalon_q1_2025_0095_4
**Page:** 104
**Rows:** 3
**Columns:** 1
**Created:** 2025-08-27T20:30:30.613598
