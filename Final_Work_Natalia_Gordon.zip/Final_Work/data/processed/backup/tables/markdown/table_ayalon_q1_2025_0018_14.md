# Table with 4 rows and 4 columns. Columns: 337 4, 905 22, 190 27 and 1 more columns. Contains 13 numeric values.

| 337 4 | 905 22 | 190 27 | 432 1-6/2025 |
|---|---|---|---|
| )157( 8 | 339 31 | 082 39 | 264 1-6/2024 |
| 494 )3 | 434( )8 | 892( )11 | 832( יוניש |
| 1 - 21 |  |  |  |

**Table ID:** table_ayalon_q1_2025_0018_14
**Page:** 24
**Rows:** 4
**Columns:** 4
**Created:** 2025-08-27T20:30:29.017819
