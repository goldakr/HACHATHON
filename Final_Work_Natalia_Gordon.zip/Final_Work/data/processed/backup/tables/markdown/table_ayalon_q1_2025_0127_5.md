# Table with 2 rows and 1 columns. Columns: יללכ חוטיב ןוכסיחו.

| יללכ חוטיב ןוכסיחו |
|---|
| כ"הס רחא כ"הס חוטיב רושיוו הרבחה תואירב חווט ךורא |

**Table ID:** table_ayalon_q1_2025_0127_5
**Page:** 136
**Rows:** 2
**Columns:** 1
**Created:** 2025-08-27T20:30:31.274581
