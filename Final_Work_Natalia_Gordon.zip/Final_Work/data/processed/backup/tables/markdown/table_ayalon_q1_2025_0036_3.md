# Table with 3 rows and 1 columns. Columns: 6492102. Contains 1 numeric values.

| 6492102 |
|---|
| רקבמה ןובשחה האור לש הריקס חוד |
| מ"עב חוטיבל הרבח ןולייא לש תוינמה ילעבל |

**Table ID:** table_ayalon_q1_2025_0036_3
**Page:** 45
**Rows:** 3
**Columns:** 1
**Created:** 2025-08-27T20:30:29.369445
