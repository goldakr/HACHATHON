# Table with 4 rows and 6 columns. Columns: 180, 036 84, 008 55 and 3 more columns. Contains 8 numeric values.

| 180 | 036 84 | 008 55 | 117 31 | 633 9 | 278 |
|---|---|---|---|---|---|
| )ב( תוימרפ ירזחה יוכינב וטורב תוימרפ |  |  |  |  |  |
| םויב המייתסנש הנשל |  |  |  |  |  |
| 2024 | רבמצדב 31 |  |  |  |  |

**Table ID:** table_ayalon_q1_2025_0110_12
**Page:** 119
**Rows:** 4
**Columns:** 6
**Created:** 2025-08-27T20:30:31.008019
