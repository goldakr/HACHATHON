# Table with 3 rows and 5 columns. Columns: 74, 290 19, 704 13 and 2 more columns. Contains 15 numeric values.

| 74 | 290 19 | 704 13 | 657 107 | 650 4-6/2025 |
|---|---|---|---|---|
| 41 | 997 30 | 712 19 | 685 92 | 393 4-6/2024 |
| 32 | 293 )11 | 009( )6 | 028( 15 | 257 יוניש |

**Table ID:** table_ayalon_q1_2025_0019_7
**Page:** 25
**Rows:** 3
**Columns:** 5
**Created:** 2025-08-27T20:30:29.083955
