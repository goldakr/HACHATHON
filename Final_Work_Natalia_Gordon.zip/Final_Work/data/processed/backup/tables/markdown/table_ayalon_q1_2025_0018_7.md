# Table with 3 rows and 5 columns. Columns: 115, 508 31, 736 21 and 2 more columns. Contains 14 numeric values.

| 115 | 508 31 | 736 21 | 100 168 | 344 1-6/2025 |
|---|---|---|---|---|
| 76 | 074 48 | 199 20 | 672 144 | 945 1-6/2024 |
| 39 | 434 )16 | 462( 427 23 | 399 יוניש |  |

**Table ID:** table_ayalon_q1_2025_0018_7
**Page:** 24
**Rows:** 3
**Columns:** 5
**Created:** 2025-08-27T20:30:29.017819
