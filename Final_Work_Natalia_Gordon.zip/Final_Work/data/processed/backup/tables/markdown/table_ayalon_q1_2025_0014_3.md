# Table with 2 rows and 1 columns. Columns: םייח חוטיב יללכ חוטיב.

| םייח חוטיב יללכ חוטיב |
|---|
| םיסימ רחאו ןוה |

**Table ID:** table_ayalon_q1_2025_0014_3
**Page:** 20
**Rows:** 2
**Columns:** 1
**Created:** 2025-08-27T20:30:28.841371
