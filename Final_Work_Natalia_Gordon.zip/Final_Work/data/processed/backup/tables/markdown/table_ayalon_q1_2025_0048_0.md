# Table with 3 rows and 1 columns. Columns: םייניב םידחואמה םייפסכה תוחודל םירואב. Contains 1 numeric values.

| םייניב םידחואמה םייפסכה תוחודל םירואב |
|---|
| )ךשמה( יללכ - :1 רואב |
| םיילכלכ ורקמ םייוניש תוכלשה .ב |

**Table ID:** table_ayalon_q1_2025_0048_0
**Page:** 57
**Rows:** 3
**Columns:** 1
**Created:** 2025-08-27T20:30:29.655557
