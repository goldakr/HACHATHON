# Table with 2 rows and 3 columns. Columns: םיסימ, רחאו ןוה, חוטיב.

| םיסימ | רחאו ןוה | חוטיב |
|---|---|---|
| תואירב | םייח חוטיב | יללכ חוטיב | חוור כ"הס |

**Table ID:** table_ayalon_q1_2025_0014_25
**Page:** 20
**Rows:** 2
**Columns:** 3
**Created:** 2025-08-27T20:30:28.842928
