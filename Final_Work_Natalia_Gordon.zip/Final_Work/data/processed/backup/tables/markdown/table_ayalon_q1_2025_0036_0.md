# Table with 2 rows and 1 columns. Columns: +972-3-6232525 .לט רריסק תא יאבג ררופ טסוק. Contains 3 numeric values.

| +972-3-6232525 .לט רריסק תא יאבג ררופ טסוק |
|---|
| +972-3-5622555 סקפ | 'א144 ןיגב םחנמ ךרד |

**Table ID:** table_ayalon_q1_2025_0036_0
**Page:** 45
**Rows:** 2
**Columns:** 1
**Created:** 2025-08-27T20:30:29.369445
