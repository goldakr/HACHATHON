# Table with 3 rows and 1 columns. Columns: מ"עב חוטיבל הרבח ןולייא. Contains 1 numeric values.

| מ"עב חוטיבל הרבח ןולייא |
|---|
| םידחואמ םייניב םייפסכ תוחוד |
| 2025 ינויב 30 םויל |

**Table ID:** table_ayalon_q1_2025_0035_1
**Page:** 44
**Rows:** 3
**Columns:** 1
**Created:** 2025-08-27T20:30:29.351215
