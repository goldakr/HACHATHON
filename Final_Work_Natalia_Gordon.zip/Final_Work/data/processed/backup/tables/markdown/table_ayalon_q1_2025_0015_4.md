# Table with 3 rows and 1 columns. Columns: םייח חוטיב חוור כ"הס.

| םייח חוטיב חוור כ"הס |
|---|
| רחאו ןוה תואירב חוטיב |
| חווט ךורא ןוכסיחו הבילה תוליעפמ |

**Table ID:** table_ayalon_q1_2025_0015_4
**Page:** 21
**Rows:** 3
**Columns:** 1
**Created:** 2025-08-27T20:30:28.878124
