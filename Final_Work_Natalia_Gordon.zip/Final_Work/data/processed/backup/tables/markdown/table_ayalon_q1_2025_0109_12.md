# Table with 4 rows and 6 columns. Columns: 353, 886 136, 325 119 and 3 more columns. Contains 8 numeric values.

| 353 | 886 136 | 325 119 | 861 78 | 925 18 | 775 |
|---|---|---|---|---|---|
| )ב( תוימרפ ירזחה יוכינב וטורב תוימרפ |  |  |  |  |  |
| םויב ומייתסהש םישדוח השישל |  |  |  |  |  |
| 2024 | ינויב 30 |  |  |  |  |

**Table ID:** table_ayalon_q1_2025_0109_12
**Page:** 118
**Rows:** 4
**Columns:** 6
**Created:** 2025-08-27T20:30:30.992531
