# Table with 3 rows and 3 columns. Columns: 4, 100 - 4, 100 תוריחס ןניאש תוינמ. Contains 9 numeric values.

| 4 | 100 - 4 | 100 תוריחס ןניאש תוינמ |
|---|---|---|
| 150 | 635 - 150 | 635 תוריחס תוינמ |
| 154 | 735 - 154 | 735 ןוה ירישכמ לכה ךס |

**Table ID:** table_ayalon_q1_2025_0113_24
**Page:** 122
**Rows:** 3
**Columns:** 3
**Created:** 2025-08-27T20:30:31.068699
