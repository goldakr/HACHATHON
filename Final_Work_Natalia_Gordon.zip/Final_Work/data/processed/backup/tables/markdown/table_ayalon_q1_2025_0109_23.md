# Table with 4 rows and 6 columns. Columns: 337, 324 145, 141 111 and 3 more columns. Contains 8 numeric values.

| 337 | 324 145 | 141 111 | 237 62 | 272 18 | 674 |
|---|---|---|---|---|---|
| )ב( תוימרפ ירזחה יוכינב וטורב תוימרפ |  |  |  |  |  |
| םויב ומייתסהש םישדוח השולשל |  |  |  |  |  |
| 2025 | ינויב 30 |  |  |  |  |

**Table ID:** table_ayalon_q1_2025_0109_23
**Page:** 118
**Rows:** 4
**Columns:** 6
**Created:** 2025-08-27T20:30:30.992531
