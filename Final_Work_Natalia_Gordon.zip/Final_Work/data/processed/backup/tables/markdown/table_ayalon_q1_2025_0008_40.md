# Table with 2 rows and 1 columns. Columns: םישדוח 6 לש הפוקתל. Contains 2 numeric values.

| םישדוח 6 לש הפוקתל |
|---|
| ינויב 30 םויב המייתסהש |

**Table ID:** table_ayalon_q1_2025_0008_40
**Page:** 13
**Rows:** 2
**Columns:** 1
**Created:** 2025-08-27T20:30:28.733965
