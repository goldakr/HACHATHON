# Table with 2 rows and 1 columns. Columns: רבמצדב 31 ינויב 30 םויל. Contains 2 numeric values.

| רבמצדב 31 ינויב 30 םויל |
|---|
| 2024 2024 2025 |

**Table ID:** table_ayalon_q1_2025_0037_2
**Page:** 46
**Rows:** 2
**Columns:** 1
**Created:** 2025-08-27T20:30:29.388155
